# Experimental Interactions Pack (Astro + React Islands + Tailwind)

A staged ladder (L1 → L5) to build and evaluate UI micro-interactions with increasing **concept + code complexity**, aligned to upstream-curious governance.

## Contents

- `L1Toast` — ephemeral feedback toast (state + timers)
- `L2ImageCompare` — pointer-controlled before/after slider (geometry)
- `L3DragList` — re-order list via HTML5 drag & drop (DOM events/state)
- `L4ParallaxCard` — 3D parallax tilt (pointer → transform mapping)
- `L5QuoteFormLite` — multi-step quote form with localStorage persistence (flows + validation)

## Usage

1. Copy `src/components/interactions/*` into your project.
2. Copy `src/styles/interactions.css` and import it in your base layout.
3. Mount sample pages from `src/pages/interactions-experimental/*` or embed components on your target pages.
4. Hydration guidance:
   - `client:visible` for in-viewport widgets (ImageCompare)
   - `client:idle` for low-priority (Toast, ParallaxCard)
   - `client:load` for must-be-ready flows (DragList, QuoteForm)
5. Add images to `/public/img/` for the examples used in pages.

## Experiments & Metrics

- **UX KPIs**: time-to-first-interaction, error rate, completion %, reorder stability
- **Perf**: island JS size, hydration mode impact, RAF vs interval drift
- **A11y**: roles/aria, keyboard access, focus management

## Extension Ideas

- Add Vitest unit tests & Playwright e2e.
- Promote L5 into your full Quote flow (serverless submit, schema, spam guard).
- Convert L3 to pointer-based drag (for mobile) if you need finer control.
- Animate L4 with spring physics (Framer Motion) if you accept extra bytes.