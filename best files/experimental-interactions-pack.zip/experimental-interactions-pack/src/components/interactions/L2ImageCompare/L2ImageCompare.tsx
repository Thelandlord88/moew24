import React, { useRef, useState } from "react";

type Props = { before: string; after: string; alt?: string };

export default function L2ImageCompare({ before, after, alt = "" }: Props) {
  const [x, setX] = useState(50); // percent
  const ref = useRef<HTMLDivElement>(null);

  const onPointer = (e: React.PointerEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const p = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100));
    setX(p);
  };

  return (
    <div
      ref={ref}
      className="relative w-full max-w-2xl aspect-video overflow-hidden rounded-2xl bg-slate-200 select-none"
      onPointerDown={onPointer}
      onPointerMove={(e) => e.buttons === 1 && onPointer(e)}
    >
      <img src={after} alt={alt} className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0" style={{ width: `${x}%`, overflow: "hidden" }}>
        <img src={before} alt={alt} className="h-full w-full object-cover" />
      </div>

      <div
        className="absolute inset-y-0"
        style={{ left: `calc(${x}% - 1px)` }}
        aria-hidden
      >
        <div className="h-full w-0.5 bg-white/80 shadow-[0_0_0_1px_rgba(0,0,0,.15)]" />
        <div className="absolute top-1/2 -translate-y-1/2 -left-4 w-8 h-8 rounded-full bg-white shadow flex items-center justify-center">
          ↔
        </div>
      </div>
    </div>
  );
}