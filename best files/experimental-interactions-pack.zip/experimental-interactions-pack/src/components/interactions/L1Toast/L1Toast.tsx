import React, { useEffect, useRef, useState } from "react";

type Props = { message?: string; duration?: number };

export default function L1Toast({ message = "Saved successfully", duration = 2200 }: Props) {
  const [open, setOpen] = useState(false);
  const t = useRef<number | null>(null);

  useEffect(() => () => t.current && window.clearTimeout(t.current), []);

  const show = () => {
    setOpen(true);
    if (t.current) window.clearTimeout(t.current);
    t.current = window.setTimeout(() => setOpen(false), duration);
  };

  return (
    <div className="space-y-3">
      <button className="btn-primary" onClick={show}>Show toast</button>
      <div
        role="status"
        aria-live="polite"
        className={`pointer-events-none fixed bottom-6 right-6 transition-all ${open ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0"}`}
      >
        <div className="rounded-xl bg-slate-900 text-white shadow-lg px-4 py-2">
          {message}
        </div>
      </div>
    </div>
  );
}