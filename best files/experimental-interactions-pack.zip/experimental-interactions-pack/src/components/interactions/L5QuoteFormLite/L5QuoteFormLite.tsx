import React, { useEffect, useState } from "react";

type Data = { name?: string; suburb?: string; bedrooms?: number; email?: string };

const steps = [
  { id: "name",    label: "Your name" },
  { id: "suburb",  label: "Suburb" },
  { id: "bed",     label: "Bedrooms" },
  { id: "email",   label: "Email" },
];

const KEY = "ond/quote-lite";

export default function L5QuoteFormLite() {
  const [i, setI] = useState(0);
  const [data, setData] = useState<Data>({});

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY) || "{}");
      setData(saved);
    } catch {}
  }, []);

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(data)); } catch {}
  }, [data]);

  const next = () => setI(Math.min(i + 1, steps.length - 1));
  const prev = () => setI(Math.max(i - 1, 0));
  const done = i === steps.length - 1;

  const submit = () => {
    alert("Submitted: " + JSON.stringify(data, null, 2));
    try { localStorage.removeItem(KEY); } catch {}
  };

  return (
    <div className="max-w-lg rounded-2xl border bg-white/80 p-4 shadow">
      <ol className="mb-3 flex flex-wrap items-center gap-2 text-sm">
        {steps.map((s, ix) => (
          <li key={s.id} className={`px-2 py-1 rounded ${ix<=i?"bg-sky-100":"bg-slate-100"}`}>{ix+1}. {s.label}</li>
        ))}
      </ol>

      {i===0 && (
        <input className="input" placeholder="Jane Doe" value={data.name||""} onChange={e=>setData({...data,name:e.target.value})}/>
      )}
      {i===1 && (
        <input className="input" placeholder="e.g., Springfield Lakes" value={data.suburb||""} onChange={e=>setData({...data,suburb:e.target.value})}/>
      )}
      {i===2 && (
        <input className="input" type="number" min={0} placeholder="Bedrooms" value={data.bedrooms ?? ""} onChange={e=>setData({...data,bedrooms:Number(e.target.value)})}/>
      )}
      {i===3 && (
        <input className="input" type="email" placeholder="you@example.com" value={data.email||""} onChange={e=>setData({...data,email:e.target.value})}/>
      )}

      <div className="mt-4 flex gap-2">
        <button className="btn-soft" onClick={prev} disabled={i===0}>Back</button>
        {!done && <button className="btn-primary" onClick={next} disabled={(i===0 && !data.name) || (i===1 && !data.suburb) || (i===2 && (data.bedrooms==null || isNaN(data.bedrooms))) || (i===3 && !/^\S+@\S+\.\S+$/.test(data.email||""))}>Next</button>}
        {done && <button className="btn-primary" onClick={submit} disabled={!/^\S+@\S+\.\S+$/.test(data.email||"")}>Submit</button>}
      </div>
    </div>
  );
}