import { useCallback, useId, useState } from "react";

export function useDisclosure(defaultOpen = false) {
  const [open, setOpen] = useState(defaultOpen);
  const id = useId();
  const toggle = useCallback(() => setOpen(v => !v), []);
  const openPanel = useCallback(() => setOpen(true), []);
  const closePanel = useCallback(() => setOpen(false), []);
  return { open, toggle, openPanel, closePanel, id };
}