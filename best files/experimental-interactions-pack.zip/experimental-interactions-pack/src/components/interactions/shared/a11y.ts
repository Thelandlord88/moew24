export const ariaDisclosure = (id: string, open: boolean) => ({
  button: { "aria-expanded": open, "aria-controls": id },
  region: { id, role: "region", "aria-hidden": !open }
});