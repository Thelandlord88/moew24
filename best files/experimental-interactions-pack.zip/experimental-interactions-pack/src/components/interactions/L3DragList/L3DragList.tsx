import React, { useRef, useState } from "react";

type Item = { id: string; label: string };
type Props = { initial: Item[] };

export default function L3DragList({ initial }: Props) {
  const [items, setItems] = useState(initial);
  const dragging = useRef<string | null>(null);

  const onDragStart = (id: string) => (e: React.DragEvent) => {
    dragging.current = id;
    e.dataTransfer.effectAllowed = "move";
  };

  const onDragOver = (overId: string) => (e: React.DragEvent) => {
    e.preventDefault();
    const dragId = dragging.current;
    if (!dragId || dragId === overId) return;
    const next = [...items];
    const from = next.findIndex(i => i.id === dragId);
    const to = next.findIndex(i => i.id === overId);
    const [m] = next.splice(from, 1);
    next.splice(to, 0, m);
    setItems(next);
  };

  const onDragEnd = () => { dragging.current = null; };

  return (
    <ul className="max-w-md space-y-2">
      {items.map(i => (
        <li
          key={i.id}
          draggable
          onDragStart={onDragStart(i.id)}
          onDragOver={onDragOver(i.id)}
          onDragEnd={onDragEnd}
          className="rounded-xl border bg-white px-3 py-2 shadow-sm cursor-grab active:cursor-grabbing"
          aria-grabbed={dragging.current === i.id}
        >
          {i.label}
        </li>
      ))}
    </ul>
  );
}