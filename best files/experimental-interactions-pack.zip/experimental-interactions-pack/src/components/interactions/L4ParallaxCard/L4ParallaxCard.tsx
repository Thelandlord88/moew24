import React, { useRef } from "react";

type Props = { title: string; subtitle?: string; image?: string };

export default function L4ParallaxCard({ title, subtitle, image }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const dx = (e.clientX - cx) / (r.width / 2);
    const dy = (e.clientY - cy) / (r.height / 2);
    el.style.transform = `rotateY(${dx * 10}deg) rotateX(${-dy * 10}deg)`;
  };

  const reset = () => {
    const el = ref.current;
    if (el) el.style.transform = "rotateY(0deg) rotateX(0deg)";
  };

  return (
    <div className="perspective-[1000px]">
      <div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={reset}
        className="relative w-80 h-56 rounded-2xl border bg-white shadow-lg overflow-hidden transition-transform will-change-transform"
        style={{ transformStyle: "preserve-3d" }}
      >
        {image && <img src={image} alt="" className="absolute inset-0 w-full h-full object-cover opacity-90" />}
        <div className="absolute inset-0 bg-gradient-to-br from-white/60 to-white/10" />
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-xl font-semibold drop-shadow">{title}</h3>
          {subtitle && <p className="text-slate-700">{subtitle}</p>}
        </div>
      </div>
    </div>
  );
}